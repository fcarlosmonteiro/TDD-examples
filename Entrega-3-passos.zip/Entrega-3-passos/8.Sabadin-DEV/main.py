from crivo import *

vetor = crivo.calc(10)
print(vetor)

coluna = crivo.coluna(vetor)
print(coluna)

tabela = crivo.tabela(vetor, 3)
print(tabela)

inverso = crivo.inv(10)
print(inverso)

vetor2 = crivo.calc(400)
tabela2 = crivo.tabela(vetor2, 10)

print(tabela2)
