from crivo import *

vetor = crivo.calc(10)
print(vetor)

coluna = crivo.coluna(vetor)
print(coluna)

tabela = crivo.tabela(vetor, 3)
print(tabela)

