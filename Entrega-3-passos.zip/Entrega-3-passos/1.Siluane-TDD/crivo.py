class crivo:
    def calc(n):
        return ""
