from crivo import *

vetor = crivo.calc(10)
print(vetor)
